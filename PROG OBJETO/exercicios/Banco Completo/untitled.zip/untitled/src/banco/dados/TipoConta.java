package banco.dados;

public enum TipoConta {
    ESPECIAL, COMUM
}
